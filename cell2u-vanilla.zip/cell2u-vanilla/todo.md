# Cell2U Vanilla Export Tasks

- [x] Create the static HTML pages for home, shop, product detail, and checkout.
- [x] Create the vanilla CSS design system and responsive layouts.
- [x] Create the JavaScript cart, wishlist, search, filters, product detail, and checkout simulation.
- [x] Create JSON product data and README instructions.
- [x] Validate JSON and static HTTP loading.
- [x] Package the export as a zip archive.
- [x] Upload the static files to the selected GitHub repository.
- [x] Confirm the GitHub commit and provide the zip download to the user.
- [ ] Optionally enable GitHub Pages in repository Settings → Pages.

> Payment processing is intentionally not included. The checkout is a frontend-only simulation.

> Images use free Unsplash URLs from `data/products.json`; replace them with owned production assets before commercial launch.

> References: [Unsplash](https://unsplash.com/), [GitHub Pages documentation](https://docs.github.com/en/pages)

## References

[Unsplash]: https://unsplash.com/ "Unsplash"
[GitHub Pages documentation]: https://docs.github.com/en/pages "GitHub Pages documentation"

## Style Decisions

The export preserves the Cell2U Clean Commerce Kinetics direction: white-first layouts, baby-blue trust and action signals, and yellow reserved for deals and discounts.

The logo rule uses the C2U monogram paired with the Cell2U wordmark throughout the static pages.

The checkout remains a simulation without payment processing or backend order creation.

## Icon and domain follow-up

- [ ] Replace emoji UI glyphs with consistent vector icons throughout all static pages.
- [ ] Validate the icon update and sync the rebuilt static export to GitHub.
- [ ] Add the requested custom domain to GitHub Pages after the user provides the exact domain name.
- [ ] Confirm DNS records at the user's domain registrar and enable GitHub Pages HTTPS once available.

> Domain configuration requires the exact domain name and access to its DNS settings. GitHub Pages SSL cannot be issued until DNS points to GitHub.

## References

[GitHub Pages documentation]: https://docs.github.com/en/pages "GitHub Pages documentation"

## GitHub synchronization recovery

- [ ] Audit the local static export and the remote `main` branch commit.
- [ ] Finish the remaining emoji replacements in the static files.
- [ ] Rebuild the zip and push the verified icon update to GitHub.
- [ ] Confirm the remote commit hash and affected file contents.

## Final delivery recovery

- [ ] Finish all remaining visible emoji replacements.
- [ ] Rebuild and validate the downloadable zip archive.
- [ ] Push the final archive and static files to GitHub.
- [ ] Verify the remote branch and deliver the archive here.

## Catalogue update

- [ ] Replace the existing JSON product list with the supplied Huawei, Samsung, Honor, and Oppo catalogue.
- [ ] Preserve the existing product fields required by the static storefront.
- [ ] Validate the JSON, rebuild the zip, and push the catalogue update to GitHub.

## WhatsApp enquiry and CMS migration

- [ ] Centralize editable business config, WhatsApp number, and messages in a data configuration file.
- [ ] Replace online checkout/payment screens with a direct WhatsApp order/enquiry route.
- [ ] Write a clear CMS guide as a Markdown file explaining how to edit products, prices, and WhatsApp numbers.
- [ ] Rebuild the zip package and sync all updates to GitHub.

## Multi-number round-robin WhatsApp routing

- [ ] Update `data/config.js` to support multiple WhatsApp numbers and round-robin state.
- [ ] Implement round-robin selection and fallback logic in a helper function.
- [ ] Update order submission and floating buttons to use the round-robin number generator.
- [ ] Update `CMS_GUIDE.md`, rebuild the zip, and push all changes to GitHub.

## SEO and content cleanup (Email, Shipping, Delivery removal)

- [ ] Remove all email, shipping, and delivery mentions from static pages (`index.html`, `shop.html`, `product.html`, `checkout.html`, `config.js`, `CMS_GUIDE.md`).
- [ ] Add robust SEO meta tags, Open Graph tags, JSON-LD structured data, `robots.txt`, and `sitemap.xml`.
- [ ] Document Google indexing steps in the README and CMS guide.
- [ ] Rebuild zip, sync to GitHub, and checkpoint.
